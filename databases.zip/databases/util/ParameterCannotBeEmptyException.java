package uk.ac.bris.cs.databases.util;

/**
 *
 * @author csxdb
 */
public class ParameterCannotBeEmptyException extends ParameterException {
    
}
