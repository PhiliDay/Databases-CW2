package uk.ac.bris.cs.databases.util;

/**
 *
 * @author csxdb
 */
public class ParameterCannotBeNullException extends ParameterException {
    
}
