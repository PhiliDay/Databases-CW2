package uk.ac.bris.cs.databases.util;

/**
 * Base class for all exceptions to catch invalid parameters.
 * @author csxdb
 */
public class ParameterException extends RuntimeException {
    
}
